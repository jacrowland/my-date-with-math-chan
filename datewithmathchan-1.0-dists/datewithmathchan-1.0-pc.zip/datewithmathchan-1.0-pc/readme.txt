******************************************************************
*** MY DATE WITH MATH CHAN | UoA Math102 Creative Work S1 2019 ***
******************************************************************

*** What is this? ***

My Date With Math Chan is a short visual novel using RenPy (a framework for building visual novels in python).

*** What is a visual novel? ***

A visual novel is an interactive narrative where the player can make choices to alter the story (essentially a choose-your-own-adventure book).

*** Why did you make this? ***

This visual novel explores my relationship and emotions towards mathematics (or "What is maths (to you)") as personified by 'Math Chan',
a fictional university student who the player attempts to ask out on a date.

I'm fully aware of how weird this is but this was fun to make and I think it's pretty unique.

*** How to play ***

1. Open the "datewithmathchan.exe" (this will boot the game).
2. Click "start".
3. Read the on-screen prompts and left-click (or space bar) to continue.
4. Select an option when it appears on screen (by left-clicking).
5. You can save at any point and return by using the "load" option from the menu.

Note: Select "help" from the menu for more assistance.

*** Who made this? ***

Jacob Rowland
UPI jrow952

*** Where did you get the images from? ***

All images used have been altered.

The original images are from the following sources:
https://commons.wikimedia.org/wiki/File:Anime_girl_publicdomainq.png
https://isrii2019.nz/wp-content/uploads/2018/06/UoA-Architecture-29.jpg
https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Albert_Park_fountain.JPG/1200px-Albert_Park_fountain.JPG
https://isrii2019.nz/wp-content/uploads/2018/06/UoA-Architecture-29.jpg
http://iaee2020.nz/wp-content/uploads/2019/02/OGGB-10.jpg
https://www.eiseverywhere.com/file_uploads/c4e3857a4074391b75416a7600ae42de_oggb8.jpg

*** Where is the music from? ***

https://www.bensound.com (licenced under Creative Commons Licence)

